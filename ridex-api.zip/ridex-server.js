/**
 * RideX API — browser-deployable build
 *
 * The previous version relied on setInterval/setTimeout to expire offers and
 * sweep stale drivers. That needs a process that never sleeps, which means a
 * machine you can SSH into. This version has no background work at all:
 * every timer became a timestamp that gets evaluated when someone asks.
 *
 * Consequence: it runs anywhere, including free hosts that sleep when idle.
 * The rider polling for their ride is what advances the dispatch loop.
 *
 * Deploy: push to GitHub, connect to Render as a Web Service.
 *   Build command:  npm install
 *   Start command:  node ridex-server.js
 */

const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const geohash = require('ngeohash');
const crypto = require('crypto');

/* Service account comes from an env var, not a file — you cannot upload a
   file to a host from a phone, but you can paste a value into a form. */
const svc = JSON.parse(
  process.env.FIREBASE_SERVICE_ACCOUNT ||
  require('fs').readFileSync('./serviceAccount.json', 'utf8')
);
admin.initializeApp({
  credential: admin.credential.cert(svc),
  databaseURL: process.env.RIDEX_DB
});

const db = admin.database();
const app = express();
app.use(cors({ origin: (process.env.RIDEX_ORIGINS || '*').split(',') }));
app.use(express.json({ limit: '64kb' }));

const COMMISSION = 0.18;
const LOCK_SEC = 180;
const OFFER_SEC = 20;          // slightly longer: polling granularity is coarser
const STALE_MS = 60000;
const FATIGUE_HOURS = 12;
const SECRET = process.env.RIDEX_SECRET || 'change-me-and-keep-it-stable';

/* ─────────────────────── fares ─────────────────────── */

const CLASSES = {
  bike:   { base:20, incl:1.5, perKm:7,  perMin:1.0, min:25,  fee:3,  gst:0,    factor:0.78 },
  auto:   { base:30, incl:1.5, perKm:12, perMin:1.2, min:35,  fee:5,  gst:0,    factor:1.12 },
  mini:   { base:50, incl:2.0, perKm:15, perMin:1.5, min:60,  fee:9,  gst:0.05, factor:1.00 },
  prime:  { base:80, incl:2.0, perKm:20, perMin:2.0, min:100, fee:12, gst:0.05, factor:1.00 },
  parcel: { base:25, incl:1.5, perKm:8,  perMin:1.0, min:30,  fee:5,  gst:0.18, factor:0.78 }
};
const WAIT = { freeMin: 3, perMin: 2 };
const CANCEL = { graceSec: 120, fee: 25 };

function fareFor(cls, km, drivingMin, stops, surge) {
  const c = CLASSES[cls];
  const mins = drivingMin * c.factor;
  const billKm = Math.max(0, km - c.incl);
  const ride = Math.max(c.base + billKm * c.perKm + mins * c.perMin, c.min) * surge;
  const stopFee = (stops || 0) * (cls === 'bike' ? 8 : 15);
  const gst = Math.round((ride + stopFee + c.fee) * c.gst);
  return {
    cls, km: +km.toFixed(2), minutes: Math.round(mins), surge,
    ride: Math.round(ride), stopFee, platformFee: c.fee, gst,
    total: Math.round(ride + stopFee + c.fee + gst), paymentMode: 'cash'
  };
}

async function routeMetrics(points) {
  const coords = points.map(p => `${p.lng},${p.lat}`).join(';');
  const res = await fetch(
    `https://router.project-osrm.org/route/v1/driving/${coords}?overview=false`);
  if (!res.ok) throw new Error('routing unavailable');
  const j = await res.json();
  const r = j.routes && j.routes[0];
  if (!r) throw new Error('no route');
  return { km: r.distance / 1000, minutes: r.duration / 60 };
}

/* Surge from live supply, computed on the spot rather than from a metrics
   table a background job would have had to maintain. */
async function surgeFor(pickup, cls) {
  const pool = await candidates(pickup, cls);
  if (pool.length >= 3) return 1;
  if (pool.length === 2) return 1.1;
  if (pool.length === 1) return 1.2;
  return 1.25;
}

/* ─────────────────────── geo ─────────────────────── */

const rad = d => d * Math.PI / 180;
function haversine(a, b) {
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const x = Math.sin(dLat/2)**2 + Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLng/2)**2;
  return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}
const cellsAround = (lat, lng) => {
  const c = geohash.encode(lat, lng, 5);
  return [c, ...geohash.neighbors(c)];
};

/* ─────────────────────── auth ─────────────────────── */

async function auth(req, res, next) {
  try {
    req.user = await admin.auth().verifyIdToken(
      (req.headers.authorization || '').replace('Bearer ', ''));
    next();
  } catch { res.status(401).json({ error: 'Please sign in again.' }); }
}
function adminOnly(req, res, next) {
  if (!req.user.admin) return res.status(403).json({ error: 'Not permitted.' });
  next();
}

const sign = q => {
  const body = JSON.stringify(q);
  return Buffer.from(body).toString('base64url') + '.' +
         crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
};
function verifyLock(token) {
  const [b, sig] = String(token).split('.');
  const body = Buffer.from(b, 'base64url').toString();
  if (sig !== crypto.createHmac('sha256', SECRET).update(body).digest('base64url'))
    throw new Error('bad lock');
  const q = JSON.parse(body);
  if (Date.now() > q.exp) throw new Error('expired');
  return q;
}

/* ═══════════════════════ matching ═══════════════════════
   Every disqualifier is checked here, at query time. Nothing depends on a
   sweeper job having run recently. */

async function candidates(pickup, cls) {
  const ids = new Set();
  await Promise.all(cellsAround(pickup.lat, pickup.lng).map(async c => {
    const s = await db.ref('geo/' + c).once('value');
    s.forEach(ch => ids.add(ch.key));
  }));

  const now = Date.now();
  const out = [];
  await Promise.all([...ids].map(async uid => {
    const [p, l] = await Promise.all([
      db.ref('drivers/' + uid).once('value'),
      db.ref('driverLoc/' + uid).once('value')
    ]);
    const prof = p.val(), loc = l.val();
    if (!prof || !loc) return;
    if (prof.status !== 'approved') return;
    if (loc.state !== 'idle') return;
    if (now - loc.ts > STALE_MS) return;                       // phone went quiet
    if (prof.onlineSince && (now - prof.onlineSince) / 3600000 > FATIGUE_HOURS) return;
    if (prof.cls !== cls && !(cls === 'parcel' && prof.cls === 'bike')) return;
    const km = haversine(loc, pickup);
    if (km > 7) return;
    out.push({ uid, prof, km, score: km - ((prof.rating || 4.5) - 4) * 0.8 });
  }));
  return out.sort((a, b) => a.score - b.score);
}

/**
 * The dispatch loop, driven by requests instead of timers.
 *
 * Called whenever anyone asks about a ride. If the standing offer has expired,
 * it is retired and the next driver is offered — so a rider polling every few
 * seconds is what keeps dispatch moving. No offer can hang forever, because
 * nobody can be waiting on a ride without something polling it.
 */
async function advance(rideId) {
  const snap = await db.ref('rides/' + rideId).once('value');
  const ride = snap.val();
  if (!ride || ride.state !== 'searching') return ride;

  const now = Date.now();
  const cur = ride.currentOffer;

  if (cur && now < cur.expires) return ride;            // still someone's turn

  if (cur) {                                            // expired — retire it
    await db.ref().update({
      [`offers/${cur.uid}/${cur.offerId}`]: null,
      [`rides/${rideId}/currentOffer`]: null
    });
  }

  // give up rather than loop forever on an empty town
  if (now - ride.createdAt > 4 * 60 * 1000) {
    await db.ref('rides/' + rideId).update({
      state: 'no_drivers',
      message: 'No partners accepted your request. Please try again in a few minutes.'
    });
    return (await db.ref('rides/' + rideId).once('value')).val();
  }

  const pool = await candidates(ride.points[0], ride.cls);
  const tried = ride.tried || {};
  let next = pool.find(c => !tried[c.uid]);

  if (!next) {
    // everyone nearby has passed once — start the list again
    if (pool.length) {
      await db.ref(`rides/${rideId}/tried`).remove();
      next = pool[0];
    } else {
      return ride;                                      // nobody online yet; keep waiting
    }
  }

  const offerId = db.ref('offers').push().key;
  await db.ref().update({
    [`offers/${next.uid}/${offerId}`]: {
      rideId, expires: now + OFFER_SEC * 1000,
      pickup: ride.addr[0], drop: ride.addr[ride.addr.length - 1],
      km: ride.fare.km, pickupKm: +next.km.toFixed(1),
      earn: Math.round(ride.fare.total * (1 - COMMISSION)),
      collect: ride.fare.total, paymentMode: 'cash'
    },
    [`rides/${rideId}/tried/${next.uid}`]: true,
    [`rides/${rideId}/currentOffer`]: {
      uid: next.uid, offerId, expires: now + OFFER_SEC * 1000
    }
  });
  return (await db.ref('rides/' + rideId).once('value')).val();
}

/* ═══════════════════════ rider ═══════════════════════ */

app.post('/rider/profile', auth, async (req, res) => {
  await db.ref('riders/' + req.user.uid).update({
    name: String(req.body.name || '').slice(0, 60),
    phone: req.user.phone_number || null,
    updatedAt: admin.database.ServerValue.TIMESTAMP
  });
  res.json({ ok: true });
});

app.post('/quote', auth, async (req, res) => {
  const { points } = req.body;
  if (!Array.isArray(points) || points.length < 2)
    return res.status(400).json({ error: 'Add a pickup and a drop.' });

  let m;
  try { m = await routeMetrics(points); }
  catch { return res.status(503).json({ error: 'Routing is unavailable. Try again in a moment.' }); }

  const quotes = {};
  for (const cls of Object.keys(CLASSES)) {
    const pool = await candidates(points[0], cls);
    const surge = pool.length >= 3 ? 1 : pool.length === 2 ? 1.1 : pool.length === 1 ? 1.2 : 1.25;
    quotes[cls] = fareFor(cls, m.km, m.minutes, points.length - 2, surge);
    quotes[cls].eta = pool.length ? Math.max(1, Math.round(pool[0].km / 0.35)) : null;
  }
  res.json({ km: m.km, minutes: m.minutes, surge: 1, quotes, lockSeconds: LOCK_SEC });
});

app.post('/quote/lock', auth, async (req, res) => {
  const { points, cls } = req.body;
  if (!CLASSES[cls]) return res.status(400).json({ error: 'Unknown vehicle type.' });
  let m;
  try { m = await routeMetrics(points); }
  catch { return res.status(503).json({ error: 'Routing is unavailable right now.' }); }

  const surge = await surgeFor(points[0], cls);
  const q = fareFor(cls, m.km, m.minutes, points.length - 2, surge);
  q.exp = Date.now() + LOCK_SEC * 1000;
  q.uid = req.user.uid;
  res.json({ fare: q, lock: sign(q), expiresAt: q.exp });
});

app.post('/ride/create', auth, async (req, res) => {
  const { points, addr, cls, lock } = req.body;
  let fare;
  try { fare = verifyLock(lock); }
  catch { return res.status(409).json({ error: 'That fare expired. Please get a fresh quote.' }); }
  if (fare.uid !== req.user.uid)
    return res.status(403).json({ error: 'That fare belongs to another account.' });

  if ((await db.ref('riderActive/' + req.user.uid).once('value')).val())
    return res.status(409).json({ error: 'You already have a ride in progress.' });

  const rider = (await db.ref('riders/' + req.user.uid).once('value')).val() || {};
  const rideId = db.ref('rides').push().key;

  await db.ref().update({
    ['rides/' + rideId]: {
      id: rideId, riderUid: req.user.uid,
      riderName: rider.name || 'Rider',
      riderPhone: req.user.phone_number || null,
      cls, points, addr, fare, paymentMode: 'cash',
      otp: 1000 + crypto.randomInt(9000),
      state: 'searching', createdAt: Date.now(), tried: {}
    },
    ['riderRides/' + req.user.uid + '/' + rideId]: true,
    ['riderActive/' + req.user.uid]: rideId
  });

  const ride = await advance(rideId);
  res.json({ rideId, otp: ride.otp, state: ride.state });
});

/** Rider polls this. It is also what drives dispatch forward. */
app.get('/ride/:id/status', auth, async (req, res) => {
  const ride = await advance(req.params.id);
  if (!ride) return res.status(404).json({ error: 'Ride not found.' });
  if (ride.riderUid !== req.user.uid && ride.driverUid !== req.user.uid)
    return res.status(403).json({ error: 'Not your ride.' });

  let driverLoc = null;
  if (ride.driverUid) {
    const l = (await db.ref('driverLoc/' + ride.driverUid).once('value')).val();
    if (l) driverLoc = { lat: l.lat, lng: l.lng, ts: l.ts };
  }
  res.json({
    state: ride.state, message: ride.message || null,
    otp: ride.otp, fare: ride.fare, waitCharge: ride.waitCharge || 0,
    driver: ride.driver || null, driverLoc,
    searchingFor: ride.state === 'searching'
      ? Math.round((Date.now() - ride.createdAt) / 1000) : null
  });
});

app.post('/ride/cancel', auth, async (req, res) => {
  const ride = (await db.ref('rides/' + req.body.rideId).once('value')).val();
  if (!ride || ride.riderUid !== req.user.uid)
    return res.status(403).json({ error: 'Not your ride.' });

  const fee = ride.assignedAt && (Date.now() - ride.assignedAt) > CANCEL.graceSec * 1000
    ? CANCEL.fee : 0;
  const up = {
    [`rides/${req.body.rideId}/state`]: 'cancelled_rider',
    [`rides/${req.body.rideId}/cancelFee`]: fee,
    [`riderActive/${req.user.uid}`]: null
  };
  if (ride.currentOffer)
    up[`offers/${ride.currentOffer.uid}/${ride.currentOffer.offerId}`] = null;
  if (ride.driverUid) {
    up[`driverLoc/${ride.driverUid}/state`] = 'idle';
    up[`driverActive/${ride.driverUid}`] = null;
  }
  await db.ref().update(up);
  res.json({ ok: true, fee });
});

app.post('/ride/sos', auth, async (req, res) => {
  const ride = (await db.ref('rides/' + req.body.rideId).once('value')).val();
  await db.ref('sos').push({
    rideId: req.body.rideId, raisedBy: req.user.uid,
    lat: req.body.lat || null, lng: req.body.lng || null, at: Date.now(),
    riderPhone: ride && ride.riderPhone || null,
    driverPhone: ride && ride.driver && ride.driver.phone || null,
    plate: ride && ride.driver && ride.driver.plate || null,
    state: 'open'
  });
  res.json({ ok: true });
});

app.post('/ride/share', auth, async (req, res) => {
  const token = crypto.randomBytes(9).toString('base64url');
  await db.ref('share/' + token).set({
    rideId: req.body.rideId, exp: Date.now() + 6 * 3600 * 1000
  });
  res.json({ url: (process.env.RIDEX_WEB || '') + '/t/?k=' + token });
});

app.get('/t/:token', async (req, res) => {
  const s = (await db.ref('share/' + req.params.token).once('value')).val();
  if (!s || Date.now() > s.exp) return res.status(404).json({ error: 'This link has expired.' });
  const ride = (await db.ref('rides/' + s.rideId).once('value')).val();
  const loc = ride.driverUid
    ? (await db.ref('driverLoc/' + ride.driverUid).once('value')).val() : null;
  res.json({
    state: ride.state,
    plate: ride.driver ? ride.driver.plate : null,
    driverName: ride.driver ? ride.driver.name : null,
    from: ride.addr[0], to: ride.addr[ride.addr.length - 1],
    position: loc ? { lat: loc.lat, lng: loc.lng, ts: loc.ts } : null
  });
});

/* ═══════════════════════ driver ═══════════════════════ */

app.post('/driver/apply', auth, async (req, res) => {
  const uid = req.user.uid;
  if ((await db.ref('drivers/' + uid + '/status').once('value')).val() === 'approved')
    return res.json({ ok: true, status: 'approved' });

  const { name, cls, plate, model, licence } = req.body;
  await db.ref('drivers/' + uid).update({
    name: String(name || '').slice(0, 60),
    phone: req.user.phone_number || null,
    cls: CLASSES[cls] ? cls : 'mini',
    plate: String(plate || '').toUpperCase().slice(0, 15),
    model: String(model || '').slice(0, 40),
    licence: String(licence || '').slice(0, 25),
    status: 'pending', rating: 5.0, trips: 0, dues: 0,
    appliedAt: admin.database.ServerValue.TIMESTAMP
  });
  res.json({ ok: true, status: 'pending' });
});

/**
 * Driver's heartbeat. Sends position, gets back the current offer or active
 * ride. Doubles as the availability signal — stop calling it and the staleness
 * check removes you from dispatch on its own.
 */
app.post('/driver/beat', auth, async (req, res) => {
  const uid = req.user.uid;
  const prof = (await db.ref('drivers/' + uid).once('value')).val();
  if (!prof) return res.json({ status: 'none' });
  if (prof.status !== 'approved')
    return res.json({ status: prof.status, name: prof.name || null });

  const { lat, lng, online } = req.body;
  const now = Date.now();

  const activeId = (await db.ref('driverActive/' + uid).once('value')).val();
  const state = activeId ? 'busy' : (online ? 'idle' : 'offline');

  if (typeof lat === 'number' && typeof lng === 'number') {
    const gh = geohash.encode(lat, lng, 5);
    const prev = (await db.ref(`driverLoc/${uid}/gh`).once('value')).val();
    const up = { [`driverLoc/${uid}`]: { lat, lng, gh, state, ts: now } };
    if (prev && prev !== gh) up[`geo/${prev}/${uid}`] = null;
    up[`geo/${gh}/${uid}`] = state === 'idle' ? true : null;
    if (online && !prof.onlineSince) up[`drivers/${uid}/onlineSince`] = now;
    if (!online) up[`drivers/${uid}/onlineSince`] = null;
    await db.ref().update(up);
  }

  // current offer, skipping any that quietly expired
  let offer = null;
  const offers = (await db.ref('offers/' + uid).once('value')).val() || {};
  for (const [id, o] of Object.entries(offers)) {
    if (o.expires > now) { offer = Object.assign({ id }, o); break; }
    await db.ref(`offers/${uid}/${id}`).remove();
  }

  let ride = null;
  if (activeId) {
    const r = (await db.ref('rides/' + activeId).once('value')).val();
    if (r && r.state !== 'completed' && !String(r.state).startsWith('cancelled')) {
      ride = {
        id: activeId, state: r.state, pickup: r.addr[0],
        drop: r.addr[r.addr.length - 1], riderName: r.riderName,
        riderPhone: r.riderPhone, fare: r.fare.total,
        earn: Math.round(r.fare.total * (1 - COMMISSION)),
        waitCharge: r.waitCharge || 0, arrivedAt: r.arrivedAt || null
      };
    } else {
      await db.ref('driverActive/' + uid).remove();
    }
  }

  const hours = prof.onlineSince ? (now - prof.onlineSince) / 3600000 : 0;
  res.json({
    status: 'approved', name: prof.name, cls: prof.cls, plate: prof.plate,
    trips: prof.trips || 0, dues: prof.dues || 0, rating: prof.rating || 5,
    hoursOnline: +hours.toFixed(2), fatigueLocked: hours > FATIGUE_HOURS,
    offer, ride
  });
});

app.post('/offer/accept', auth, async (req, res) => {
  const { rideId, offerId } = req.body;
  const uid = req.user.uid;

  const prof = (await db.ref('drivers/' + uid).once('value')).val();
  if (!prof || prof.status !== 'approved')
    return res.status(403).json({ error: 'Your account is not approved yet.' });

  // transaction: two drivers can never both win the same ride
  const r = await db.ref(`rides/${rideId}/currentOffer`).transaction(cur => {
    if (!cur || cur.uid !== uid || cur.offerId !== offerId) return;
    if (Date.now() > cur.expires) return;
    return null;
  });
  if (!r.committed)
    return res.status(409).json({ error: 'That request went to another partner.' });

  await db.ref().update({
    [`rides/${rideId}/state`]: 'assigned',
    [`rides/${rideId}/driverUid`]: uid,
    [`rides/${rideId}/driver`]: {
      name: prof.name, rating: prof.rating || 5, plate: prof.plate,
      model: prof.model, phone: prof.phone || null
    },
    [`rides/${rideId}/assignedAt`]: Date.now(),
    [`driverRides/${uid}/${rideId}`]: true,
    [`driverActive/${uid}`]: rideId,
    [`offers/${uid}/${offerId}`]: null,
    [`driverLoc/${uid}/state`]: 'busy'
  });
  res.json({ ok: true });
});

app.post('/offer/pass', auth, async (req, res) => {
  const { rideId, offerId } = req.body;
  await db.ref().update({
    [`offers/${req.user.uid}/${offerId}`]: null,
    [`rides/${rideId}/currentOffer`]: null
  });
  await advance(rideId);                 // straight to the next driver
  res.json({ ok: true });
});

app.post('/ride/arrived', auth, async (req, res) => {
  const ride = (await db.ref('rides/' + req.body.rideId).once('value')).val();
  if (!ride || ride.driverUid !== req.user.uid)
    return res.status(403).json({ error: 'Not your ride.' });
  await db.ref('rides/' + req.body.rideId).update({ state: 'arrived', arrivedAt: Date.now() });
  res.json({ ok: true });
});

app.post('/ride/start', auth, async (req, res) => {
  const { rideId, otp } = req.body;
  const ride = (await db.ref('rides/' + rideId).once('value')).val();
  if (!ride || ride.driverUid !== req.user.uid)
    return res.status(403).json({ error: 'Not your ride.' });
  if (ride.state !== 'arrived')
    return res.status(409).json({ error: 'Mark yourself as arrived first.' });

  const tries = (ride.otpTries || 0) + 1;
  if (String(ride.otp) !== String(otp)) {
    await db.ref('rides/' + rideId).update({ otpTries: tries });
    if (tries >= 5) return res.status(429).json({ error: 'Too many wrong attempts. Contact support.' });
    return res.status(400).json({ error: 'Wrong OTP. Ask the rider to read it again.' });
  }

  const waitMin = (Date.now() - ride.arrivedAt) / 60000;
  await db.ref('rides/' + rideId).update({
    state: 'ontrip', startedAt: Date.now(),
    waitCharge: Math.max(0, Math.round((waitMin - WAIT.freeMin) * WAIT.perMin))
  });
  res.json({ ok: true });
});

app.post('/ride/complete', auth, async (req, res) => {
  const ride = (await db.ref('rides/' + req.body.rideId).once('value')).val();
  if (!ride || ride.driverUid !== req.user.uid)
    return res.status(403).json({ error: 'Not your ride.' });

  const collected = ride.fare.total + (ride.waitCharge || 0);
  const commission = Math.round(collected * COMMISSION);
  const uid = req.user.uid;

  await db.ref().update({
    [`rides/${req.body.rideId}/state`]: 'completed',
    [`rides/${req.body.rideId}/endedAt`]: Date.now(),
    [`rides/${req.body.rideId}/collected`]: collected,
    [`rides/${req.body.rideId}/commission`]: commission,
    [`drivers/${uid}/dues`]: admin.database.ServerValue.increment(commission),
    [`drivers/${uid}/trips`]: admin.database.ServerValue.increment(1),
    [`ledger/${uid}/${req.body.rideId}`]: { collected, commission, at: Date.now() },
    [`driverLoc/${uid}/state`]: 'idle',
    [`driverActive/${uid}`]: null,
    [`riderActive/${ride.riderUid}`]: null
  });
  res.json({ ok: true, collect: collected, yourShare: collected - commission, commission });
});

app.post('/ride/driver-cancel', auth, async (req, res) => {
  const { rideId, reason } = req.body;
  const uid = req.user.uid;
  await db.ref().update({
    [`rides/${rideId}/state`]: 'searching',
    [`rides/${rideId}/driverUid`]: null,
    [`rides/${rideId}/driver`]: null,
    [`rides/${rideId}/currentOffer`]: null,
    [`driverLoc/${uid}/state`]: 'idle',
    [`driverActive/${uid}`]: null,
    [`drivers/${uid}/cancelCount`]: admin.database.ServerValue.increment(1),
    [`driverCancels/${uid}/${rideId}`]: { at: Date.now(), reason: reason || null }
  });
  await advance(rideId);
  res.json({ ok: true });
});

/* ═══════════════════════ admin ═══════════════════════ */

/**
 * One-time admin bootstrap, so you never need a terminal to grant yourself
 * access. Call it once from a browser with the secret, then unset the env var.
 */
app.get('/admin/bootstrap', async (req, res) => {
  const want = process.env.RIDEX_BOOTSTRAP;
  if (!want) return res.status(410).json({ error: 'Bootstrap is closed.' });
  if (req.query.secret !== want) return res.status(403).json({ error: 'Wrong secret.' });
  if (!req.query.phone) return res.status(400).json({ error: 'Add ?phone=+9198...' });
  try {
    const u = await admin.auth().getUserByPhoneNumber(req.query.phone);
    await admin.auth().setCustomUserClaims(u.uid, { admin: true });
    res.json({ ok: true, uid: u.uid,
      note: 'Sign out and back in. Now remove RIDEX_BOOTSTRAP from your env vars.' });
  } catch (e) {
    res.status(404).json({ error: 'No account with that number. Sign in to the app first.' });
  }
});

app.get('/admin/drivers', auth, adminOnly, async (req, res) => {
  const s = await db.ref('drivers').once('value');
  const out = [];
  s.forEach(c => out.push(Object.assign({ uid: c.key }, c.val())));
  res.json(out.sort((a, b) => (b.appliedAt || 0) - (a.appliedAt || 0)));
});

app.post('/admin/driver/status', auth, adminOnly, async (req, res) => {
  const { uid, status } = req.body;
  if (!['approved', 'pending', 'suspended'].includes(status))
    return res.status(400).json({ error: 'Unknown status.' });
  const up = { [`drivers/${uid}/status`]: status, [`drivers/${uid}/reviewedAt`]: Date.now() };
  if (status !== 'approved') {
    const gh = (await db.ref(`driverLoc/${uid}/gh`).once('value')).val();
    if (gh) up[`geo/${gh}/${uid}`] = null;
  }
  await db.ref().update(up);
  res.json({ ok: true });
});

app.post('/admin/driver/settle', auth, adminOnly, async (req, res) => {
  await db.ref().update({
    [`drivers/${req.body.uid}/dues`]: admin.database.ServerValue.increment(-Math.abs(req.body.amount)),
    [`settlements/${req.body.uid}/${Date.now()}`]: { amount: req.body.amount, by: req.user.uid }
  });
  res.json({ ok: true });
});

app.get('/admin/live', auth, adminOnly, async (req, res) => {
  const [rides, sos] = await Promise.all([
    db.ref('rides').orderByChild('createdAt').startAt(Date.now() - 6*3600*1000).once('value'),
    db.ref('sos').orderByChild('at').startAt(Date.now() - 24*3600*1000).once('value')
  ]);
  const active = [], alerts = [];
  rides.forEach(c => {
    const r = c.val();
    if (r.state !== 'completed' && !String(r.state).startsWith('cancelled'))
      active.push({ id: c.key, state: r.state, rider: r.riderName,
        driver: r.driver ? r.driver.name : null,
        from: r.addr && r.addr[0], to: r.addr && r.addr[r.addr.length-1],
        fare: r.fare && r.fare.total });
  });
  sos.forEach(c => alerts.push(Object.assign({ id: c.key }, c.val())));
  res.json({ active, alerts });
});

app.get('/health', (_, res) => res.json({ ok: true, at: Date.now() }));

app.listen(process.env.PORT || 8090, () =>
  console.log('RideX API listening on ' + (process.env.PORT || 8090)));
