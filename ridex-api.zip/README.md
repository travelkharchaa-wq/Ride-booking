# RideX API

No background timers. Dispatch advances whenever a rider or driver polls,
so this runs fine on hosts that sleep when idle.

## Deploy on Render (browser only)

1. Push these two files to a GitHub repo.
2. render.com → New → Web Service → connect the repo.
3. Build: `npm install` · Start: `node ridex-server.js`
4. Environment variables:

| Key | Value |
|---|---|
| `RIDEX_DB` | your Realtime Database URL |
| `RIDEX_SECRET` | any long random string — never change it |
| `RIDEX_ORIGINS` | `https://ridebooking.online` |
| `RIDEX_WEB` | `https://ridebooking.online` |
| `FIREBASE_SERVICE_ACCOUNT` | the entire serviceAccount.json contents, pasted as one line |
| `RIDEX_BOOTSTRAP` | a secret you invent — delete it after step 6 |

5. Deploy, then check `https://your-app.onrender.com/health`
6. Grant yourself admin, once:
   `https://your-app.onrender.com/admin/bootstrap?secret=YOUR_SECRET&phone=+919876543210`
   Then delete `RIDEX_BOOTSTRAP` from the env vars.

## Keeping it awake

Render's free tier sleeps after 15 minutes idle, and a cold start takes ~40 s —
long enough that a rider thinks the app is broken. Set up a free ping at
cron-job.org hitting `/health` every 10 minutes.
